"""Entry point for scht_lab application."""
from scht_lab import app

if __name__=='__main__':
    app()